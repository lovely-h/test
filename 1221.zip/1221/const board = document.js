const board = document.getElementById('board');
const status = document.getElementById('status');
let currentPlayer = 'X';
let cells = Array(9).fill(null);
let gameOver = false;

function createBoard() {
  board.innerHTML = '';
  cells.forEach((_, i) => {
    const cell = document.createElement('div');
    cell.className = 'cell';
    cell.dataset.index = i;
    cell.onclick = handleMove;
    board.appendChild(cell);
  });
}

function handleMove(e) {
  const index = e.target.dataset.index;
  if (cells[index] || gameOver) return;
  cells[index] = currentPlayer;
  e.target.textContent = currentPlayer;
  if (checkWin(currentPlayer)) {
    status.textContent = `玩家 ${currentPlayer} 获胜！`;
    gameOver = true;
  } else if (cells.every(cell => cell)) {
    status.textContent = '平局！';
    gameOver = true;
  } else {
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    status.textContent = `当前玩家: ${currentPlayer}`;
  }
}

function checkWin(player) {
  const wins = [
    [0,1,2],[3,4,5],[6,7,8],
    [0,3,6],[1,4,7],[2,5,8],
    [0,4,8],[2,4,6]
  ];
  return wins.some(combo => combo.every(i => cells[i] === player));
}

function resetGame() {
  cells = Array(9).fill(null);
  currentPlayer = 'X';
  gameOver = false;
  status.textContent = `当前玩家: ${currentPlayer}`;
  createBoard();
}

createBoard();